//>>built
define("dijit/form/nls/ro/Textarea",({iframeEditTitle:"zonă de editare",iframeFocusTitle:"cadru zonă de editare"}));
